"""
FEVER preprocessing utilities.

FEVER contains 185,445 claims with labels Supported, Refuted, or
NotEnoughInfo. The original dataset also provides evidence annotations for
Supported/Refuted claims.

This module normalizes raw FEVER records into the schema used by the pilot
runner. It deliberately preserves the original record ID and evidence fields
so every result remains auditable.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional
import json


LABEL_MAP = {
    "SUPPORTS": "SUPPORTED",
    "SUPPORTED": "SUPPORTED",
    "REFUTES": "REFUTED",
    "REFUTED": "REFUTED",
    "NOT ENOUGH INFO": "NOT_ENOUGH_INFO",
    "NOTENOUGHINFO": "NOT_ENOUGH_INFO",
}


@dataclass
class FeverRecord:
    record_id: str
    claim: str
    label: str
    evidence: List[str]
    split: str
    raw_id: Any = None


def normalize_label(label: str) -> str:
    key = str(label).strip().upper()
    return LABEL_MAP.get(key, key)


def extract_evidence_from_fever_item(item: Dict[str, Any]) -> List[str]:
    evidence_texts = []

    # FEVER evidence is commonly nested as evidence groups.
    for group in item.get("evidence", []) or []:
        if not isinstance(group, list):
            continue
        for evidence_item in group:
            if not isinstance(evidence_item, list):
                continue

            # The final FEVER fields may include wiki page, sentence ID,
            # sentence text, etc. We preserve text when supplied.
            for field in reversed(evidence_item):
                if isinstance(field, str) and field.strip():
                    # Avoid treating page IDs as full evidence when no text is present.
                    if len(field.split()) >= 3:
                        evidence_texts.append(field.strip())
                        break

    # Some converted datasets expose evidence as a direct list of strings.
    for item_text in item.get("evidence_text", []) or []:
        if isinstance(item_text, str):
            evidence_texts.append(item_text.strip())

    # Deduplicate while preserving order.
    seen = set()
    output = []
    for text in evidence_texts:
        if text and text not in seen:
            seen.add(text)
            output.append(text)
    return output


def normalize_item(item: Dict[str, Any], split: str) -> FeverRecord:
    raw_id = item.get("id", item.get("record_id"))
    claim = item.get("claim", item.get("text", ""))
    label = normalize_label(item.get("label", ""))
    evidence = extract_evidence_from_fever_item(item)

    return FeverRecord(
        record_id=str(raw_id),
        claim=str(claim),
        label=label,
        evidence=evidence,
        split=split,
        raw_id=raw_id,
    )


def load_huggingface_fever(
    split: str = "labelled_dev",
    limit: Optional[int] = None,
) -> List[FeverRecord]:
    """
    Load the original FEVER v1 dataset through Hugging Face.

    The FEVER dataset card documents 185,445 claims and the Supported,
    Refuted and NotEnoughInfo labels. Exact split naming can depend on the
    dataset revision; verify the selected split before the final paper run.
    """
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise ImportError("Install the `datasets` package.") from exc

    # The dataset repository exposes a v1.0 configuration.
    ds = load_dataset("fever/fever", "v1.0", split=split)

    if limit is not None:
        ds = ds.select(range(min(limit, len(ds))))

    return [normalize_item(dict(row), split) for row in ds]


def save_jsonl(records: Iterable[FeverRecord], path: str):
    with open(path, "w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(asdict(record), ensure_ascii=False) + "\n")
