"""Item-level and retrieval metrics for the FEVER pilot."""

from __future__ import annotations

from typing import Iterable, Sequence
import numpy as np


LABELS = ["SUPPORTED", "REFUTED", "NOT_ENOUGH_INFO"]


def accuracy(y_true, y_pred):
    if not y_true:
        return 0.0
    return sum(a == b for a, b in zip(y_true, y_pred)) / len(y_true)


def macro_f1(y_true, y_pred):
    try:
        from sklearn.metrics import f1_score
        return float(
            f1_score(
                y_true, y_pred,
                labels=LABELS,
                average="macro",
                zero_division=0,
            )
        )
    except ImportError:
        return 0.0


def binary_hallucination_f1(y_true, y_pred):
    """
    Optional binary metric: REFUTED/NOT_ENOUGH_INFO vs SUPPORTED.

    Use only if this mapping is explicitly defined in the paper's evaluation
    protocol. It is not a substitute for the standard FEVER score.
    """
    try:
        from sklearn.metrics import f1_score
        yt = [0 if x == "SUPPORTED" else 1 for x in y_true]
        yp = [0 if x == "SUPPORTED" else 1 for x in y_pred]
        return float(f1_score(yt, yp, zero_division=0))
    except ImportError:
        return 0.0
