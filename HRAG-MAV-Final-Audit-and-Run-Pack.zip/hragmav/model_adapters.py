"""
Real Hugging Face model adapters for HRAG-MAV.

Supports:
- meta-llama/Meta-Llama-3-8B-Instruct
- Qwen/Qwen2-7B-Instruct

These adapters load the actual models with Transformers. They do not fabricate
responses. Llama 3 requires authorized Hugging Face access; Qwen2 is openly
listed on Hugging Face under its model card.

Use a GPU with sufficient VRAM or an approved quantized/offloaded deployment
for 7B/8B models.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Optional
import time


MODEL_IDS = {
    "Llama-3": "meta-llama/Meta-Llama-3-8B-Instruct",
    "Qwen2": "Qwen/Qwen2-7B-Instruct",
}


@dataclass
class GenerationResult:
    text: str
    prompt_tokens: int
    completion_tokens: int
    latency_s: float
    model_id: str


class HuggingFaceGenerator:
    def __init__(
        self,
        generator: str,
        device_map: str = "auto",
        torch_dtype: str = "auto",
        max_new_tokens: int = 256,
        temperature: float = 0.0,
        top_p: float = 1.0,
    ):
        if generator not in MODEL_IDS:
            raise ValueError(f"Unknown generator: {generator}")

        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as exc:
            raise ImportError(
                "Install torch and transformers before loading the generator."
            ) from exc

        self.generator = generator
        self.model_id = MODEL_IDS[generator]
        self.max_new_tokens = max_new_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_id,
            device_map=device_map,
            torch_dtype=torch_dtype,
        )

    def generate(self, prompt: str) -> GenerationResult:
        import torch

        messages = [{"role": "user", "content": prompt}]
        if hasattr(self.tokenizer, "apply_chat_template"):
            inputs = self.tokenizer.apply_chat_template(
                messages,
                add_generation_prompt=True,
                return_tensors="pt",
            )
        else:
            inputs = self.tokenizer(prompt, return_tensors="pt").input_ids

        device = self.model.device
        inputs = inputs.to(device)

        start = time.perf_counter()
        with torch.no_grad():
            outputs = self.model.generate(
                inputs,
                max_new_tokens=self.max_new_tokens,
                do_sample=self.temperature > 0,
                temperature=max(self.temperature, 1e-5),
                top_p=self.top_p,
            )
        elapsed = time.perf_counter() - start

        generated = outputs[0][inputs.shape[-1]:]
        text = self.tokenizer.decode(generated, skip_special_tokens=True)

        return GenerationResult(
            text=text.strip(),
            prompt_tokens=int(inputs.shape[-1]),
            completion_tokens=int(generated.shape[-1]),
            latency_s=float(elapsed),
            model_id=self.model_id,
        )


def make_fact_check_prompt(claim: str, evidence: List[str]) -> str:
    evidence_block = "\n".join(
        f"[Evidence {i+1}] {text}" for i, text in enumerate(evidence)
    )
    return f"""You are a factual verification assistant.

Determine whether the CLAIM is SUPPORTED, REFUTED, or NOT_ENOUGH_INFO by the
provided evidence.

CLAIM:
{claim}

EVIDENCE:
{evidence_block}

Return exactly:
VERDICT: <SUPPORTED|REFUTED|NOT_ENOUGH_INFO>
RATIONALE: <one concise sentence>
"""


def parse_verdict(text: str) -> Dict[str, str]:
    verdict = "NOT_ENOUGH_INFO"
    rationale = text.strip()

    for candidate in ("SUPPORTED", "REFUTED", "NOT_ENOUGH_INFO"):
        if candidate in text.upper():
            verdict = candidate
            break

    for line in text.splitlines():
        if line.upper().startswith("RATIONALE:"):
            rationale = line.split(":", 1)[1].strip()

    return {"verdict": verdict, "rationale": rationale}
