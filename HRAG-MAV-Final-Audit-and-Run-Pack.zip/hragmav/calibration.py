"""Probability calibration and calibration metrics for HRAG-MAV."""

from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np


def _logit(p):
    p = np.clip(np.asarray(p, dtype=float), 1e-7, 1 - 1e-7)
    return np.log(p / (1 - p))


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


@dataclass
class TemperatureScaling:
    """Temperature scaling fitted on a calibration split only."""

    temperature: float = 1.0

    def fit(self, probabilities, labels, grid=None):
        probabilities = np.asarray(probabilities, dtype=float)
        labels = np.asarray(labels, dtype=float)

        if grid is None:
            grid = np.linspace(0.25, 4.0, 151)

        logits = _logit(probabilities)
        best_t = 1.0
        best_loss = float("inf")

        for t in grid:
            p = _sigmoid(logits / t)
            loss = -np.mean(
                labels * np.log(np.clip(p, 1e-12, 1))
                + (1 - labels) * np.log(np.clip(1 - p, 1e-12, 1))
            )
            if loss < best_loss:
                best_loss = loss
                best_t = float(t)

        self.temperature = best_t
        return self

    def transform(self, probabilities):
        return _sigmoid(_logit(probabilities) / self.temperature)


def expected_calibration_error(probabilities, labels, n_bins=10):
    p = np.asarray(probabilities, dtype=float)
    y = np.asarray(labels, dtype=float)
    edges = np.linspace(0, 1, n_bins + 1)
    ece = 0.0

    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (p >= lo) & (p < hi if hi < 1 else p <= hi)
        if not np.any(mask):
            continue
        acc = np.mean(y[mask])
        conf = np.mean(p[mask])
        ece += np.mean(mask) * abs(acc - conf)
    return float(ece)


def brier_score(probabilities, labels):
    p = np.asarray(probabilities, dtype=float)
    y = np.asarray(labels, dtype=float)
    return float(np.mean((p - y) ** 2))
