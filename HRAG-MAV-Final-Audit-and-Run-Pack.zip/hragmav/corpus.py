"""Retrieval-corpus loaders.

The final FEVER evaluation should use a fixed Wikipedia corpus/version rather
than gold evidence snippets. This module accepts an externally prepared JSONL
corpus with records:
{"id": "...", "text": "..."}.

It also provides a deliberately small corpus builder for engineering tests.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List


def load_jsonl_corpus(path: str | Path) -> List[Dict[str, str]]:
    docs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            item = json.loads(line)
            if "id" not in item or "text" not in item:
                raise ValueError("Every corpus row needs id and text.")
            docs.append({"id": str(item["id"]), "text": str(item["text"])})
    return docs


def save_jsonl_corpus(docs: Iterable[Dict[str, str]], path: str | Path):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        for d in docs:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")


def build_debug_corpus_from_records(records, path: str | Path):
    """
    Engineering-only helper.

    DO NOT use this corpus for the final FEVER retrieval evaluation because it
    is derived from annotated records and can leak gold evidence.
    """
    docs = []
    seen = set()
    for r in records:
        for i, text in enumerate(getattr(r, "evidence", []) or []):
            key = f"{r.record_id}_{i}"
            if key not in seen and text:
                docs.append({"id": key, "text": text})
                seen.add(key)
    save_jsonl_corpus(docs, path)
