"""
True end-to-end HRAG-MAV runner.

Pipeline:
claim/question -> adaptive hybrid retrieval -> reranking ->
atomic claim verification -> entailment -> grounding -> adjudication ->
agreement-aware confidence fusion -> raw audit record.

This module requires a real retrieval corpus. It never substitutes gold FEVER
evidence for retrieved evidence. That separation is essential for a valid
retrieval evaluation.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Dict, List

from .claims import AtomicClaimExtractor
from .retrieval import AdaptiveHybridRetriever
from .agents import EntailmentAgent, GroundingAgent, AdjudicatorAgent
from .fusion import ConfidenceFusion


class EndToEndHRAGMAV:
    def __init__(
        self,
        documents: List[Dict[str, str]],
        retriever=None,
        claim_extractor=None,
        entailment_agent=None,
        grounding_agent=None,
        adjudicator_agent=None,
        fusion=None,
    ):
        self.retriever = retriever or AdaptiveHybridRetriever(documents)
        self.claim_extractor = claim_extractor or AtomicClaimExtractor()
        self.entailment_agent = entailment_agent or EntailmentAgent()
        self.grounding_agent = grounding_agent or GroundingAgent()
        self.adjudicator_agent = adjudicator_agent or AdjudicatorAgent()
        self.fusion = fusion or ConfidenceFusion()

    def verify(self, response: str) -> Dict:
        claims = self.claim_extractor.extract(response)
        claim_results = []

        for claim in claims:
            evidence, trace = self.retriever.retrieve(claim.text)
            evidence_text = [e.text for e in evidence]

            entailment = self.entailment_agent.verify(
                claim.text, evidence_text
            )
            grounding = self.grounding_agent.verify(
                claim.text, evidence_text
            )

            initial = [entailment, grounding]
            values = [x.veracity for x in initial]
            agreement = 1.0 - min(1.0, max(values) - min(values))

            adjudicator = None
            if (
                agreement < self.fusion.agreement_threshold
                or abs(sum(values) / len(values) - 0.5)
                < self.fusion.decision_margin
            ):
                adjudicator = self.adjudicator_agent.adjudicate(
                    claim.text, evidence_text, entailment, grounding
                )
                initial.append(adjudicator)

            fused = self.fusion.fuse(initial)

            claim_results.append({
                "claim_id": claim.claim_id,
                "claim": claim.text,
                "verdict": fused.verdict,
                "veracity": fused.veracity,
                "hallucination_score": fused.hallucination_score,
                "confidence": fused.confidence,
                "agreement": fused.agreement,
                "evidence": [asdict(x) for x in evidence],
                "agents": [asdict(x) for x in initial],
                "retrieval_trace": asdict(trace),
            })

        return {
            "claims": claim_results,
            "response_hallucination_score": (
                sum(x["hallucination_score"] for x in claim_results)
                / len(claim_results)
                if claim_results else 0.0
            ),
        }
