"""Experiment logging utilities.

The logger writes machine-readable JSONL and CSV files so each experimental
run can be traced to a configuration and random seed.
"""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any


class ExperimentLogger:
    def __init__(self, log_dir: str = "logs", run_name: str = "experiment"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self.run_id = f"{run_name}_{stamp}"
        self.jsonl_path = self.log_dir / f"{self.run_id}.jsonl"
        self.csv_path = self.log_dir / f"{self.run_id}.csv"
        self._csv_fields = None

    def log(self, record: Dict[str, Any]) -> None:
        payload = dict(record)
        payload.setdefault("run_id", self.run_id)
        payload.setdefault(
            "timestamp_utc",
            datetime.now(timezone.utc).isoformat(),
        )

        with self.jsonl_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, default=str) + "\n")

        fields = sorted(payload.keys())
        if self._csv_fields is None:
            self._csv_fields = fields
            with self.csv_path.open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fields)
                writer.writeheader()
                writer.writerow({k: payload.get(k, "") for k in fields})
        else:
            # Preserve a stable schema once created.
            with self.csv_path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(
                    f, fieldnames=self._csv_fields, extrasaction="ignore"
                )
                writer.writerow(payload)

    def paths(self):
        return {"jsonl": str(self.jsonl_path), "csv": str(self.csv_path)}
