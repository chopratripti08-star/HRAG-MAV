"""
Atomic claim extraction for HRAG-MAV.

The manuscript describes generative claim decomposition followed by a named-entity
coverage guard and deduplication. This module exposes a model-agnostic interface so
the actual LLM can be supplied by the experimental environment.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Sequence, Set


@dataclass
class Claim:
    claim_id: str
    text: str


def _simple_entities(text: str) -> Set[str]:
    """Lightweight fallback entity approximation."""
    import re
    return set(re.findall(r"\b[A-Z][A-Za-z0-9_-]{2,}\b", text))


def deduplicate_claims(claims: Sequence[str]) -> List[str]:
    seen = set()
    result = []
    for claim in claims:
        normalized = " ".join(claim.strip().split()).lower()
        if normalized and normalized not in seen:
            seen.add(normalized)
            result.append(claim.strip())
    return result


class AtomicClaimExtractor:
    def __init__(
        self,
        llm_decomposer: Callable[[str], List[str]] | None = None,
        use_entity_guard: bool = True,
    ):
        self.llm_decomposer = llm_decomposer
        self.use_entity_guard = use_entity_guard

    def extract(self, response: str) -> List[Claim]:
        if self.llm_decomposer is not None:
            raw_claims = self.llm_decomposer(response)
        else:
            raw_claims = self._sentence_fallback(response)

        raw_claims = [str(x).strip() for x in raw_claims if str(x).strip()]

        if self.use_entity_guard:
            response_entities = _simple_entities(response)
            covered = set()
            for c in raw_claims:
                covered |= _simple_entities(c)

            missing = response_entities - covered
            if missing:
                for sentence in self._sentence_fallback(response):
                    if _simple_entities(sentence) & missing:
                        raw_claims.append(sentence)

        raw_claims = deduplicate_claims(raw_claims)
        return [Claim(f"C{i:04d}", text) for i, text in enumerate(raw_claims, 1)]

    @staticmethod
    def _sentence_fallback(response: str) -> List[str]:
        import re
        parts = re.split(r"(?<=[.!?])\s+", response.strip())
        return [p.strip() for p in parts if p.strip()]
