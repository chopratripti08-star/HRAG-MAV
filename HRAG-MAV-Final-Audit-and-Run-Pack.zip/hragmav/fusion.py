"""
Agreement-aware confidence fusion and calibration for HRAG-MAV.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence
import math
import statistics


@dataclass
class FusionResult:
    veracity: float
    hallucination_score: float
    confidence: float
    agreement: float
    verdict: str


class TemperatureCalibrator:
    def __init__(self, temperature: float = 1.0):
        self.temperature = float(temperature)

    def transform(self, probability: float) -> float:
        probability = min(max(float(probability), 1e-6), 1 - 1e-6)
        logit = math.log(probability / (1 - probability))
        scaled = logit / self.temperature
        return 1.0 / (1.0 + math.exp(-scaled))


def agreement_score(veracities: Sequence[float]) -> float:
    if not veracities:
        return 0.0
    if len(veracities) == 1:
        return 1.0
    sd = statistics.pstdev(veracities)
    # For probabilities in [0,1], maximum useful dispersion is bounded.
    return max(0.0, min(1.0, 1.0 - 2.0 * sd))


class ConfidenceFusion:
    def __init__(
        self,
        weights: dict[str, float] | None = None,
        temperature: float = 1.0,
        agreement_threshold: float = 0.60,
        decision_margin: float = 0.10,
    ):
        self.weights = weights or {
            "entailment": 0.5,
            "grounding": 0.5,
            "adjudicator": 1.0,
        }
        self.calibrator = TemperatureCalibrator(temperature)
        self.agreement_threshold = agreement_threshold
        self.decision_margin = decision_margin

    def fuse(self, agent_results: Sequence) -> FusionResult:
        values = []
        weights = []

        for result in agent_results:
            if result.agent not in self.weights:
                continue
            values.append(float(result.veracity))
            weights.append(float(self.weights[result.agent]))

        if not values:
            return FusionResult(0.5, 0.5, 0.0, 0.0, "NEI")

        total_weight = sum(weights)
        raw = sum(v * w for v, w in zip(values, weights)) / total_weight
        agreement = agreement_score(values)

        calibrated = self.calibrator.transform(raw)
        hallucination = 1.0 - calibrated

        if raw >= 0.5 + self.decision_margin:
            verdict = "SUPPORTED"
        elif raw <= 0.5 - self.decision_margin:
            verdict = "REFUTED"
        else:
            verdict = "NEI"

        decisiveness = min(1.0, abs(raw - 0.5) * 2.0)
        confidence = min(1.0, decisiveness * (0.5 + 0.5 * agreement))

        return FusionResult(
            calibrated,
            hallucination,
            confidence,
            agreement,
            verdict,
        )
