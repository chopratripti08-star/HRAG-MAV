"""
End-to-end HRAG-MAV reference pipeline.

Maps to the manuscript's seven stages:
input acquisition -> adaptive hybrid retrieval -> reranking ->
claim extraction -> multi-agent verification -> confidence fusion ->
explainable output.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Dict, Sequence

from .claims import AtomicClaimExtractor
from .fusion import ConfidenceFusion
from .agents import EntailmentAgent, GroundingAgent, AdjudicatorAgent
from .retrieval import AdaptiveHybridRetriever


class HRAGMAVPipeline:
    def __init__(
        self,
        documents: Sequence[Dict[str, str]],
        retriever: AdaptiveHybridRetriever | None = None,
        claim_extractor: AtomicClaimExtractor | None = None,
        entailment_agent: EntailmentAgent | None = None,
        grounding_agent: GroundingAgent | None = None,
        adjudicator_agent: AdjudicatorAgent | None = None,
        fusion: ConfidenceFusion | None = None,
    ):
        self.retriever = retriever or AdaptiveHybridRetriever(documents)
        self.claim_extractor = claim_extractor or AtomicClaimExtractor()
        self.entailment_agent = entailment_agent or EntailmentAgent()
        self.grounding_agent = grounding_agent or GroundingAgent()
        self.adjudicator_agent = adjudicator_agent or AdjudicatorAgent()
        self.fusion = fusion or ConfidenceFusion()

    def verify_response(self, response: str) -> Dict:
        claims = self.claim_extractor.extract(response)
        results = []

        for claim in claims:
            evidence, trace = self.retriever.retrieve(claim.text)

            evidence_text = [e.text for e in evidence]

            entailment = self.entailment_agent.verify(
                claim.text, evidence_text
            )
            grounding = self.grounding_agent.verify(
                claim.text, evidence_text
            )

            adjudicator = None
            preliminary = [entailment, grounding]

            preliminary_veracities = [x.veracity for x in preliminary]
            agreement = (
                1.0 if len(preliminary_veracities) == 1
                else max(
                    0.0,
                    1.0 - 2.0 * (
                        sum(
                            (x - sum(preliminary_veracities) /
                             len(preliminary_veracities)) ** 2
                            for x in preliminary_veracities
                        ) / len(preliminary_veracities)
                    ) ** 0.5,
                )
            )

            raw = sum(preliminary_veracities) / len(preliminary_veracities)
            if agreement < self.fusion.agreement_threshold or abs(raw - 0.5) < self.fusion.decision_margin:
                adjudicator = self.adjudicator_agent.adjudicate(
                    claim.text, evidence_text, entailment, grounding
                )
                preliminary.append(adjudicator)

            fused = self.fusion.fuse(preliminary)

            results.append({
                "claim_id": claim.claim_id,
                "claim": claim.text,
                "verdict": fused.verdict,
                "hallucination_score": fused.hallucination_score,
                "confidence": fused.confidence,
                "agreement": fused.agreement,
                "evidence": [asdict(e) for e in evidence],
                "agents": [asdict(a) for a in preliminary],
                "retrieval_trace": asdict(trace),
            })

        supported = sum(r["verdict"] == "SUPPORTED" for r in results)
        faithfulness = supported / len(results) if results else 0.0

        confidence_sum = sum(r["confidence"] for r in results)
        if confidence_sum:
            hallucination_score = sum(
                r["hallucination_score"] * r["confidence"] for r in results
            ) / confidence_sum
        else:
            hallucination_score = 0.0

        return {
            "claims": results,
            "response_level": {
                "faithfulness": faithfulness,
                "hallucination_score": hallucination_score,
            },
        }
