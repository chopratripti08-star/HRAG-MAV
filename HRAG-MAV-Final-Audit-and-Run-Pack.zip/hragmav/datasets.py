"""Dataset adapters for the five benchmark families described in the manuscript.

The loaders intentionally return normalized records rather than silently
pretending that every benchmark has the same annotation schema. Dataset-specific
conversion should be validated against the exact split/version used in the study.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class BenchmarkRecord:
    dataset: str
    record_id: str
    question: str
    response: str = ""
    label: Optional[int] = None
    evidence: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class DatasetAdapter:
    name = "base"

    def load(self, split: str = "validation", limit: Optional[int] = None):
        raise NotImplementedError


class HuggingFaceAdapter(DatasetAdapter):
    """Generic adapter; dataset name/config must be verified before use."""

    hf_name: str = ""
    hf_config: Optional[str] = None

    def load(self, split="validation", limit=None):
        try:
            from datasets import load_dataset
        except ImportError as exc:
            raise ImportError("Install `datasets` to use benchmark adapters.") from exc

        kwargs = {}
        if self.hf_config:
            ds = load_dataset(self.hf_name, self.hf_config, split=split, **kwargs)
        else:
            ds = load_dataset(self.hf_name, split=split, **kwargs)

        if limit:
            ds = ds.select(range(min(limit, len(ds))))

        return ds


class FEVERAdapter(HuggingFaceAdapter):
    name = "FEVER"
    hf_name = "fever"


class HaluEvalAdapter(HuggingFaceAdapter):
    name = "HaluEval"
    hf_name = "pminervini/HaluEval"


class TruthfulQAAdapter(HuggingFaceAdapter):
    name = "TruthfulQA"
    hf_name = "truthful_qa"
    hf_config = "generation"


class HotpotQAAdapter(HuggingFaceAdapter):
    name = "HotpotQA"
    hf_name = "hotpot_qa"
    hf_config = "distractor"


class NaturalQuestionsAdapter(HuggingFaceAdapter):
    name = "Natural Questions"
    hf_name = "google-research-datasets/natural_questions"


DATASET_ADAPTERS = {
    "fever": FEVERAdapter,
    "halu_eval": HaluEvalAdapter,
    "truthfulqa": TruthfulQAAdapter,
    "hotpotqa": HotpotQAAdapter,
    "natural_questions": NaturalQuestionsAdapter,
}


def list_supported_datasets():
    return sorted(DATASET_ADAPTERS)


def get_adapter(name: str) -> DatasetAdapter:
    key = name.lower().replace("-", "_").replace(" ", "_")
    if key not in DATASET_ADAPTERS:
        raise KeyError(f"Unsupported dataset adapter: {name}")
    return DATASET_ADAPTERS[key]()
