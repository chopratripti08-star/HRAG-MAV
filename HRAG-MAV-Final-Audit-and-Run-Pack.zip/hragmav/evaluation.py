"""Statistical evaluation utilities used by the HRAG-MAV experiments."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Sequence, Tuple

import numpy as np
from scipy import stats


@dataclass
class MetricResult:
    precision: float
    recall: float
    f1: float
    accuracy: float


def classification_metrics(y_true, y_pred) -> MetricResult:
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

    return MetricResult(
        precision=float(precision_score(y_true, y_pred, average="binary", zero_division=0)),
        recall=float(recall_score(y_true, y_pred, average="binary", zero_division=0)),
        f1=float(f1_score(y_true, y_pred, average="binary", zero_division=0)),
        accuracy=float(accuracy_score(y_true, y_pred)),
    )


def bootstrap_ci(
    values: Sequence[float],
    statistic=np.mean,
    n_resamples: int = 10000,
    confidence: float = 0.95,
    seed: int = 42,
) -> Tuple[float, float, float]:
    """Percentile bootstrap CI. Returns statistic, lower, upper."""
    x = np.asarray(values, dtype=float)
    if x.size == 0:
        raise ValueError("values must not be empty")

    rng = np.random.default_rng(seed)
    estimates = np.empty(n_resamples, dtype=float)

    for i in range(n_resamples):
        sample = rng.choice(x, size=x.size, replace=True)
        estimates[i] = statistic(sample)

    alpha = 1 - confidence
    lo, hi = np.quantile(estimates, [alpha / 2, 1 - alpha / 2])
    return float(statistic(x)), float(lo), float(hi)


def paired_cohens_d(x, y):
    """Paired Cohen's d using the standard deviation of paired differences."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    d = x - y
    sd = np.std(d, ddof=1)
    return float(np.mean(d) / sd) if sd > 0 else 0.0


def cliffs_delta(x, y):
    """Cliff's delta for two independent samples."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    greater = sum(a > b for a in x for b in y)
    less = sum(a < b for a in x for b in y)
    return float((greater - less) / (len(x) * len(y)))


def paired_tests(x, y) -> Dict[str, float]:
    """Paired t-test and Wilcoxon signed-rank test."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    t_stat, t_p = stats.ttest_rel(x, y, nan_policy="omit")

    try:
        w_stat, w_p = stats.wilcoxon(x, y)
    except ValueError:
        w_stat, w_p = np.nan, np.nan

    return {
        "paired_t": float(t_stat),
        "paired_t_p": float(t_p),
        "wilcoxon": float(w_stat) if np.isfinite(w_stat) else np.nan,
        "wilcoxon_p": float(w_p) if np.isfinite(w_p) else np.nan,
        "cohens_d": paired_cohens_d(x, y),
        "cliffs_delta": cliffs_delta(x, y),
    }


def holm_bonferroni(p_values: Sequence[float]) -> np.ndarray:
    """Return Holm-adjusted p-values in the original order."""
    p = np.asarray(p_values, dtype=float)
    n = len(p)
    order = np.argsort(p)
    adjusted = np.empty(n, dtype=float)

    running = 0.0
    for rank, idx in enumerate(order):
        value = min(1.0, (n - rank) * p[idx])
        running = max(running, value)
        adjusted[idx] = running

    return adjusted


def paired_delta_ci(
    x,
    y,
    n_resamples: int = 10000,
    confidence: float = 0.95,
    seed: int = 42,
):
    delta = np.asarray(x, dtype=float) - np.asarray(y, dtype=float)
    return bootstrap_ci(
        delta,
        statistic=np.mean,
        n_resamples=n_resamples,
        confidence=confidence,
        seed=seed,
    )


def summarize_run(metric_values: Dict[str, Sequence[float]], seed: int = 42):
    output = {}
    for metric, values in metric_values.items():
        estimate, lo, hi = bootstrap_ci(values, seed=seed)
        output[metric] = {
            "value": estimate,
            "ci_low": lo,
            "ci_high": hi,
        }
    return output
