"""
HRAG-MAV Reference Implementation
Adaptive hybrid retrieval: BM25 + dense retrieval + RRF + cross-encoder reranking.

This module implements the retrieval logic described in Algorithm 2 of the manuscript.
It is a reference implementation and must be validated against the authors' experimental
environment before being described as the exact implementation used to obtain published
results.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple
import math

try:
    from rank_bm25 import BM25Okapi
except ImportError:
    BM25Okapi = None

try:
    from sentence_transformers import SentenceTransformer, CrossEncoder
except ImportError:
    SentenceTransformer = CrossEncoder = None


@dataclass
class Evidence:
    doc_id: str
    text: str
    score: float
    source: str = "hybrid"


@dataclass
class RetrievalTrace:
    dense_weight: float
    candidate_count: int
    reranked_scores: List[float]
    document_ids: List[str]


def _normalize_entropy(scores: Sequence[float]) -> float:
    """Return normalized Shannon entropy for a non-negative score distribution."""
    if not scores:
        return 1.0
    vals = [max(float(x), 0.0) for x in scores]
    total = sum(vals)
    if total <= 0:
        return 1.0
    probs = [x / total for x in vals if x > 0]
    if len(probs) <= 1:
        return 0.0
    entropy = -sum(p * math.log(p) for p in probs)
    return entropy / math.log(len(probs))


def _rank_map(items: Sequence[Tuple[str, float]]) -> Dict[str, int]:
    return {doc_id: rank for rank, (doc_id, _) in enumerate(items, start=1)}


def reciprocal_rank_fusion(
    dense: Sequence[Tuple[str, float]],
    sparse: Sequence[Tuple[str, float]],
    alpha: float = 0.5,
    k0: int = 60,
) -> List[Tuple[str, float]]:
    """Fuse two ranked lists using weighted reciprocal-rank fusion."""
    rd = _rank_map(dense)
    rs = _rank_map(sparse)
    ids = set(rd) | set(rs)
    scores = {}
    for doc_id in ids:
        value = 0.0
        if doc_id in rd:
            value += alpha / (k0 + rd[doc_id])
        if doc_id in rs:
            value += (1.0 - alpha) / (k0 + rs[doc_id])
        scores[doc_id] = value
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


class AdaptiveHybridRetriever:
    """
    Hybrid retriever following the manuscript's design:
    BM25 + dense retrieval -> adaptive weight -> RRF -> cross-encoder reranking.
    """

    def __init__(
        self,
        documents: Sequence[Dict[str, str]],
        dense_model: str = "sentence-transformers/all-mpnet-base-v2",
        cross_encoder_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2",
        bm25_topk: int = 50,
        dense_topk: int = 50,
        rerank_topm: int = 5,
        rrf_k: int = 60,
        device: str | None = None,
    ):
        self.documents = list(documents)
        self.bm25_topk = bm25_topk
        self.dense_topk = dense_topk
        self.rerank_topm = rerank_topm
        self.rrf_k = rrf_k

        if BM25Okapi is None:
            raise ImportError("Install rank-bm25 to use AdaptiveHybridRetriever.")

        self.tokenized = [d["text"].lower().split() for d in self.documents]
        self.bm25 = BM25Okapi(self.tokenized)

        self.encoder = None
        self.cross_encoder = None
        if SentenceTransformer is not None:
            self.encoder = SentenceTransformer(dense_model, device=device)
        if CrossEncoder is not None:
            self.cross_encoder = CrossEncoder(cross_encoder_model, device=device)

        self.embeddings = None
        if self.encoder is not None:
            self.embeddings = self.encoder.encode(
                [d["text"] for d in self.documents],
                normalize_embeddings=True,
                show_progress_bar=False,
            )

    def _bm25(self, query: str) -> List[Tuple[str, float]]:
        scores = self.bm25.get_scores(query.lower().split())
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
        return [(self.documents[i]["id"], float(score))
                for i, score in ranked[: self.bm25_topk]]

    def _dense(self, query: str) -> List[Tuple[str, float]]:
        if self.encoder is None or self.embeddings is None:
            raise RuntimeError("Dense model is unavailable.")
        q = self.encoder.encode([query], normalize_embeddings=True)[0]
        scores = self.embeddings @ q
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
        return [(self.documents[i]["id"], float(score))
                for i, score in ranked[: self.dense_topk]]

    @staticmethod
    def _overlap(a: Sequence[Tuple[str, float]], b: Sequence[Tuple[str, float]], k: int = 10) -> float:
        sa = {x[0] for x in a[:k]}
        sb = {x[0] for x in b[:k]}
        union = sa | sb
        return len(sa & sb) / len(union) if union else 0.0

    def retrieve(self, query: str, adaptive_weighting: bool = True):
        dense = self._dense(query)
        sparse = self._bm25(query)

        rd = 1.0 - _normalize_entropy([x[1] for x in dense])
        rs = 1.0 - _normalize_entropy([x[1] for x in sparse])
        overlap = self._overlap(dense, sparse)

        rd = 0.5 * rd + 0.5 * overlap
        rs = 0.5 * rs + 0.5 * overlap

        if adaptive_weighting:
            denom = rd + rs
            alpha = rd / denom if denom else 0.5
            alpha = min(max(alpha, 0.05), 0.95)
        else:
            alpha = 0.5

        fused = reciprocal_rank_fusion(
            dense, sparse, alpha=alpha, k0=self.rrf_k
        )
        candidates = fused[: max(self.rerank_topm * 5, self.rerank_topm)]

        lookup = {d["id"]: d["text"] for d in self.documents}
        rerank_scores = []

        if self.cross_encoder is not None:
            pairs = [(query, lookup[doc_id]) for doc_id, _ in candidates]
            scores = self.cross_encoder.predict(pairs)
            rerank_scores = [float(s) for s in scores]
            order = sorted(
                range(len(candidates)),
                key=lambda i: rerank_scores[i],
                reverse=True,
            )[: self.rerank_topm]
            final = [
                Evidence(candidates[i][0], lookup[candidates[i][0]],
                         rerank_scores[i], "hybrid-reranked")
                for i in order
            ]
        else:
            final = [
                Evidence(doc_id, lookup[doc_id], score, "hybrid-rrf")
                for doc_id, score in candidates[: self.rerank_topm]
            ]
            rerank_scores = [e.score for e in final]

        trace = RetrievalTrace(
            dense_weight=alpha,
            candidate_count=len(candidates),
            reranked_scores=rerank_scores,
            document_ids=[e.doc_id for e in final],
        )
        return final, trace
