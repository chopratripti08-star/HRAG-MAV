"""Baseline interfaces for the HRAG-MAV experimental comparison."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Sequence


@dataclass
class BaselineResult:
    system: str
    score: float
    verdict: str
    rationale: str = ""


class Baseline:
    name = "base"

    def predict(self, question: str, response: str, evidence: Sequence[str] = ()):
        raise NotImplementedError


class StandardLLM(Baseline):
    """Placeholder interface for the no-retrieval LLM baseline."""

    name = "Standard LLM"

    def __init__(self, verifier: Callable | None = None):
        self.verifier = verifier

    def predict(self, question, response, evidence=()):
        if self.verifier is None:
            raise RuntimeError(
                "Supply the actual generator/verifier used in the experiment."
            )
        return self.verifier(question, response)


class StandardRAG(Baseline):
    """Standard dense-retrieval + single verification baseline interface."""

    name = "Standard RAG"

    def __init__(self, retriever=None, verifier=None):
        self.retriever = retriever
        self.verifier = verifier

    def predict(self, question, response, evidence=()):
        if self.retriever is None or self.verifier is None:
            raise RuntimeError("Configure the actual RAG baseline components.")
        retrieved = self.retriever.retrieve(question)
        passages = [x.text for x in retrieved[0]]
        return self.verifier(question, response, passages)


class RetrievalOnly(Baseline):
    name = "Retrieval-only"

    def __init__(self, scorer=None, threshold=0.5):
        self.scorer = scorer
        self.threshold = threshold

    def predict(self, question, response, evidence=()):
        if self.scorer is None:
            raise RuntimeError("Configure the retrieval relevance scorer.")
        score = float(self.scorer(question, response, evidence))
        verdict = "SUPPORTED" if score >= self.threshold else "REFUTED"
        return BaselineResult(self.name, score, verdict)


class SelfCheckGPT(Baseline):
    """Interface for the sampling-based SelfCheckGPT comparator."""

    name = "SelfCheckGPT"

    def __init__(self, sampler=None, n_samples=10):
        self.sampler = sampler
        self.n_samples = n_samples

    def predict(self, question, response, evidence=()):
        if self.sampler is None:
            raise RuntimeError("Configure the actual sampling implementation.")
        score = float(self.sampler(question, response, self.n_samples))
        return BaselineResult(
            self.name,
            score,
            "REFUTED" if score >= 0.5 else "SUPPORTED",
        )


class SingleNLIVerifier(Baseline):
    """Single-model NLI verifier used to isolate the multi-agent contribution."""

    name = "Single-NLI Verifier"

    def __init__(self, verifier=None):
        self.verifier = verifier

    def predict(self, question, response, evidence=()):
        if self.verifier is None:
            raise RuntimeError("Configure the actual NLI verifier.")
        score = float(self.verifier(response, evidence))
        return BaselineResult(
            self.name,
            score,
            "SUPPORTED" if score >= 0.5 else "REFUTED",
        )


def baseline_registry():
    return {
        "standard_llm": StandardLLM,
        "standard_rag": StandardRAG,
        "retrieval_only": RetrievalOnly,
        "selfcheckgpt": SelfCheckGPT,
        "single_nli": SingleNLIVerifier,
    }
