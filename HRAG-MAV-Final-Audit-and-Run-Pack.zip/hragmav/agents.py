"""
HRAG-MAV verification agents.

The manuscript defines three roles:
1. Entailment agent
2. Grounding agent
3. Adjudicator

The implementations below provide explicit interfaces and conservative defaults.
The adjudicator may be connected to an LLM through a callable supplied by the user.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Sequence

try:
    from transformers import pipeline as hf_pipeline
except ImportError:
    hf_pipeline = None


@dataclass
class AgentVerdict:
    agent: str
    verdict: str
    veracity: float
    rationale: str


def _label_to_verdict(label: str, score: float):
    label = label.lower()
    if "entail" in label or "support" in label:
        return "SUPPORTED", score
    if "contrad" in label or "refut" in label:
        return "REFUTED", score
    return "NEI", 0.5


class EntailmentAgent:
    def __init__(self, model_name: str = "microsoft/deberta-v3-large-mnli",
                 device: int = -1):
        self.classifier = None
        if hf_pipeline is not None:
            self.classifier = hf_pipeline(
                "text-classification",
                model=model_name,
                device=device,
                top_k=None,
            )

    def verify(self, claim: str, evidence: Sequence[str]) -> AgentVerdict:
        if not evidence:
            return AgentVerdict("entailment", "NEI", 0.0, "No evidence supplied.")

        if self.classifier is None:
            return AgentVerdict(
                "entailment", "NEI", 0.5,
                "Entailment model unavailable; reference fallback."
            )

        best = None
        for passage in evidence:
            result = self.classifier(f"{passage} [SEP] {claim}")
            if result and isinstance(result[0], list):
                result = result[0]
            for item in result:
                verdict, score = _label_to_verdict(
                    item.get("label", ""), float(item.get("score", 0.0))
                )
                candidate = (score, verdict)
                if best is None or candidate[0] > best[0]:
                    best = candidate

        score, verdict = best
        return AgentVerdict(
            "entailment", verdict, score,
            f"Best evidence-level NLI decision: {verdict}."
        )


class GroundingAgent:
    def verify(self, claim: str, evidence: Sequence[str]) -> AgentVerdict:
        if not evidence:
            return AgentVerdict("grounding", "REFUTED", 0.0, "No evidence supplied.")

        claim_tokens = {
            t.lower() for t in claim.split()
            if len(t.strip(".,!?;:()[]")) > 3
        }
        evidence_tokens = {
            t.lower().strip(".,!?;:()[]") for e in evidence for t in e.split()
        }
        overlap = len(claim_tokens & evidence_tokens) / max(len(claim_tokens), 1)

        if overlap >= 0.5:
            return AgentVerdict(
                "grounding", "SUPPORTED", overlap,
                f"Token-level grounding coverage={overlap:.3f}."
            )

        return AgentVerdict(
            "grounding", "NEI", overlap,
            f"Insufficient grounding coverage={overlap:.3f}."
        )


class AdjudicatorAgent:
    def __init__(self, llm_callable: Callable | None = None):
        self.llm_callable = llm_callable

    def adjudicate(
        self,
        claim: str,
        evidence: Sequence[str],
        entailment: AgentVerdict,
        grounding: AgentVerdict,
    ) -> AgentVerdict:
        if self.llm_callable is not None:
            result = self.llm_callable(
                claim=claim,
                evidence=list(evidence),
                entailment=entailment,
                grounding=grounding,
            )
            return AgentVerdict(
                "adjudicator",
                result["verdict"],
                float(result["veracity"]),
                result.get("rationale", ""),
            )

        # Conservative deterministic fallback.
        if entailment.verdict == grounding.verdict == "SUPPORTED":
            verdict, score = "SUPPORTED", (entailment.veracity + grounding.veracity) / 2
        elif entailment.verdict == "REFUTED":
            verdict, score = "REFUTED", entailment.veracity
        else:
            verdict, score = "NEI", 0.5

        return AgentVerdict(
            "adjudicator", verdict, score,
            "Deterministic fallback adjudication from agent agreement."
        )
