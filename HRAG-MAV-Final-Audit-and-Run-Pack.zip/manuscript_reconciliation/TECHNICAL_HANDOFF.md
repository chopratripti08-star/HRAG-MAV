# One-Page Technical Handoff — HRAG-MAV

## Goal

Run the genuine FEVER pilot and then the complete experiment without changing the
research specification.

## Required environment

- NVIDIA GPU suitable for 7B/8B inference
- Hugging Face account
- Access to Llama-3-8B-Instruct
- Qwen2-7B-Instruct
- FEVER labelled-dev data
- fixed Wikipedia retrieval corpus/version
- Python environment from requirements.txt

## First command sequence

```bash
python scripts/prepare_fever.py --split labelled_dev --limit 10
```

Then supply:

```text
data/fever/retrieval_corpus.jsonl
```

with:

```json
{"id":"document-id","text":"document text"}
```

Then:

```bash
python scripts/run_hragmav_fever_e2e.py   --input data/fever/fever_pilot.jsonl   --corpus data/fever/retrieval_corpus.jsonl   --generator Qwen2   --max-records 10   --output results/raw/fever_qwen2_pilot.csv
```

Inspect the output before scaling.

Then run Llama-3.

## Required raw artifacts

For every final run preserve:

- run_id
- seed
- model ID/revision
- dataset revision
- retrieval corpus hash
- configuration hash
- hardware
- per-item prediction
- retrieved document IDs
- retrieved scores
- agent verdicts
- fused confidence
- latency
- tokens

## Scientific decision rule

If regenerated results differ from the manuscript, correct the manuscript.
Never modify the experiment to force agreement.
