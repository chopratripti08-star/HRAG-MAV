# Reviewer Response — Reproducibility (Draft)

## Comment: Data Availability / Reproducibility

**Draft response to use after actual runs are completed:**

> Thank you for identifying this issue. We have substantially strengthened the
> reproducibility package. The repository now includes the complete HRAG-MAV
> implementation, environment specifications, configuration files, dataset
> adapters, experiment runner, statistical analysis code, calibration code,
> per-example raw prediction outputs, and scripts that regenerate the reported
> tables. We also provide run-level metadata including seed, model revision,
> dataset/split, retrieval-corpus version and execution environment.
>
> We have removed the placeholder repository statement and replaced it with the
> permanent repository/archive identifier.
>
> For each reported result, the analysis now follows the trace:
> raw per-item predictions → metric calculation → bootstrap confidence interval
> → paired statistical analysis → publication table.
>
> **Important:** this response should only be submitted after the raw
> experimental outputs and public repository are actually available.

## Comment: Results are unusually clean

**If only one seed was actually executed:**

> We agree that the original presentation could be interpreted as implying
> cross-seed stability. We have clarified that the reported experiment used a
> single fixed seed and that the 95% bootstrap intervals quantify uncertainty
> over evaluation observations rather than independent seed variability. We now
> explicitly identify the absence of multi-seed replication as a limitation.

**If N independent seeds were actually executed:**

> We repeated the experiment across N independent seeds and now report the
> per-seed mean and standard deviation in the supplementary material, together
> with the 95% bootstrap confidence intervals over evaluation observations.

Replace N with the actual number only.
