# HRAG-MAV Phase 2 — Core Reference Implementation

This package implements the core methodological components described in the
HRAG-MAV manuscript:

- `retrieval.py`: adaptive BM25 + dense retrieval, RRF fusion, and cross-encoder reranking
- `claims.py`: atomic claim extraction and entity-coverage guard
- `agents.py`: entailment, grounding, and adjudication interfaces
- `fusion.py`: agreement-aware confidence fusion and temperature calibration
- `pipeline.py`: end-to-end orchestration

## Important reproducibility note

These files constitute a **reference implementation of the manuscript methodology**.
They must not be represented as the exact experimental implementation that generated
the manuscript's reported numerical results unless the authors validate that correspondence.

## Relationship to the manuscript

The implementation follows the seven-stage pipeline described in the methodology:

1. input acquisition
2. adaptive hybrid retrieval
3. evidence reranking
4. claim extraction
5. collaborative verification
6. confidence fusion and calibration
7. explainable output generation

The code should be integrated with the Phase 1 configuration and the later dataset,
baseline, and evaluation modules.
