import numpy as np

from hragmav.evaluation import (
    bootstrap_ci,
    paired_cohens_d,
    holm_bonferroni,
)
from hragmav.calibration import brier_score, expected_calibration_error


def test_bootstrap_ci():
    value, lo, hi = bootstrap_ci([1, 2, 3, 4, 5], n_resamples=100, seed=42)
    assert lo <= value <= hi


def test_paired_d():
    assert paired_cohens_d([2, 3, 4], [1, 2, 3]) > 0


def test_holm():
    adjusted = holm_bonferroni([0.001, 0.02, 0.5])
    assert all(0 <= x <= 1 for x in adjusted)


def test_calibration_metrics():
    assert brier_score([0, 1], [0, 1]) == 0
    assert expected_calibration_error([0.5, 0.5], [0, 1]) == 0
