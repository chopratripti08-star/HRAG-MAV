def test_core_imports():
    from hragmav import pipeline, retrieval, claims, agents, fusion
    from hragmav import datasets, baselines, evaluation, calibration, logger, utils
    assert pipeline is not None
