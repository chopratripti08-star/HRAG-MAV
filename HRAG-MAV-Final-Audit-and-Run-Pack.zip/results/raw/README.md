# Raw Experimental Outputs

This directory is reserved for the **actual outputs of completed experiments**.

## Required principle

Do not manually type or edit the numerical results that appear in the manuscript
into these files.

Each row should originate from an executed experiment and include:

- run ID
- seed
- generator
- dataset
- record ID
- system/baseline
- gold label
- prediction
- confidence score
- evidence metrics where applicable
- latency
- token usage
- escalation status

A complete run should be retained as an immutable CSV before any aggregation.

## Expected experiment matrix

The manuscript reports two generators:

- Llama-3
- Qwen2

and six systems:

- Standard LLM
- Standard RAG
- Retrieval-only
- SelfCheckGPT
- Single-NLI Verifier
- HRAG-MAV

across:

- FEVER
- HaluEval
- TruthfulQA
- HotpotQA
- Natural Questions

The manuscript states that detection thresholds are optimized on a calibration split,
not the test split, and that reported confidence intervals use 10,000-resample
percentile bootstrap unless otherwise indicated.
