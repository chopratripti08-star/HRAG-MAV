# FEVER Pilot Outputs

This folder is for genuine model-backed pilot outputs.

Do not put fabricated or manuscript-copied metrics here.

Expected file:
`fever_hragmav_e2e.csv`

A pilot is successful only when its rows come from an actual model run and
retrieval corpus.
