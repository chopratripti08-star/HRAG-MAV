# Processed Results

Aggregated results derived from `results/raw/`.

Keep processing deterministic and record:

- source raw CSV
- configuration hash
- seed
- processing script version
- timestamp

Never overwrite raw experimental data with processed values.
