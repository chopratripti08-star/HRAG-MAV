# Manuscript Tables

This directory receives generated table CSVs.

Expected outputs:

- `table2_main_detection.csv`
- `table3_paired_comparisons.csv`
- `table4_evidence_faithfulness_calibration.csv`
- `table5_ablation.csv`
- `table6_sensitivity.csv`

Tables should be generated from completed raw outputs rather than manually
reconstructed from the manuscript.
