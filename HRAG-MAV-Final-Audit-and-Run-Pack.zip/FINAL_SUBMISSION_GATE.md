# FINAL SUBMISSION GATE

Do not replace this checklist with confidence that the repository looks complete.

- [ ] Real Qwen2 FEVER pilot completed
- [ ] Real Llama-3 FEVER pilot completed
- [ ] Independent retrieval corpus documented
- [ ] Raw outputs retained
- [ ] Full FEVER run completed
- [ ] Remaining datasets completed
- [ ] All baseline runs completed
- [ ] Multiple seeds completed OR single-seed limitation explicitly disclosed
- [ ] Tables 2–6 regenerated from raw outputs
- [ ] Error examples taken from real failed cases
- [ ] Author placeholders removed
- [ ] AI-use disclosure completed
- [ ] GitHub repository public
- [ ] Long-term archive/release created
- [ ] Manuscript numbers checked against repository outputs
