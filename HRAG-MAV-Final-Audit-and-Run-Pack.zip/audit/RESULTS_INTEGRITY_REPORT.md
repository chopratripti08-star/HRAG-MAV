# HRAG-MAV Results Integrity Report

## Bottom line

I cannot generate valid paper-level experimental results in the current
ChatGPT runtime because the required 7B/8B model weights, the full FEVER/Wikipedia
retrieval corpus, and the benchmark files are not available in the working
environment.

I therefore did **not** fabricate replacement results.

Instead, this pack contains:
1. the complete Phase 1–5B implementation;
2. a compute-ready pilot notebook;
3. a machine-readable transcription of the manuscript's reported Table 2;
4. numerical integrity checks;
5. a submission/reviewer reconciliation checklist.

## Important observation about the manuscript

The manuscript says all confidence intervals are 95% percentile bootstrap intervals
with 10,000 resamples and that a seed is set for reproducibility. It does not
state a number of independent experimental seeds.

That means the current text should not be changed to “N=5 seeds” or similar unless
five independent runs actually exist.

## CI consistency check

The reported Table 2 CIs are highly regular. Many F1 intervals have a width of
exactly 0.024 (e.g., 0.842 [0.832, 0.852]) or approximately the same width.

This is not proof of an error, but it is exactly the kind of pattern that makes
the reviewer's “too clean” concern reasonable.

## Mean-F1 versus Mean-Accuracy

The manuscript explicitly labels the final column “Mean Acc.” and says it is
“averaged across all five datasets.” Therefore it should not automatically be
recomputed as the arithmetic mean of the five F1 values.

For example, Llama-3 HRAG-MAV has five reported F1 values:
0.842, 0.812, 0.734, 0.801 and 0.784.

Their arithmetic mean is 0.7946, whereas the reported Mean Acc. is 0.836.
This is not necessarily inconsistent because the column is accuracy rather than
F1. However, the underlying five accuracy values should be preserved in the raw
results so the reported 0.836 can be independently reproduced.

## What must happen before submission

The reported values should be regenerated from:
raw per-item predictions
→ calibration
→ metric calculation
→ bootstrap
→ paired comparisons
→ table CSVs.

The repository already contains the machinery for this. The remaining missing
piece is actual execution on the benchmark/model environment.

## Do not do

- Do not copy the manuscript numbers into “raw” CSVs.
- Do not add a fictional seed count.
- Do not tune thresholds against the test set.
- Do not use FEVER gold evidence as the retrieval corpus.
- Do not claim that a pilot proves the published Table 2.
- Do not claim that a repository is reproducible until the raw artifacts exist.
