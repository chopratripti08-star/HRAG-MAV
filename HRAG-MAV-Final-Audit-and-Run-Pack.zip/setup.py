from setuptools import setup, find_packages

setup(
    name="hragmav",
    version="0.1.0",
    author="Mahek Dey",
    author_email="deymahek39@gmail.com",
    description=(
        "Reference implementation of Hybrid Retrieval-Augmented Generation "
        "with Collaborative Multi-Agent Verification"
    ),
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.10",
)
