# HRAG-MAV

**Hybrid Retrieval-Augmented Generation with Collaborative Multi-Agent Verification for Explainable Hallucination Detection in Large Language Models**

This repository is being developed as a research reproducibility/reference implementation for the HRAG-MAV manuscript.

## Repository purpose

HRAG-MAV combines:

- Adaptive hybrid retrieval
- Cross-encoder evidence re-ranking
- Atomic claim decomposition
- Collaborative multi-agent verification
- Agreement-aware confidence fusion
- Explainable claim-level outputs

## Phase 1

Phase 1 provides the repository skeleton, environment specifications, configuration, packaging metadata, and reproducibility documentation.

## Installation

### pip

```bash
git clone https://github.com/<username>/HRAG-MAV.git
cd HRAG-MAV
pip install -r requirements.txt
pip install -e .
```

### Conda

```bash
conda env create -f environment.yml
conda activate hragmav
pip install -e .
```

## Configuration

The main configuration is:

```text
configs/default.yaml
```

It contains retrieval, model, verification, calibration, evaluation, and reproducibility settings.

## Planned modules

```text
hragmav/
    pipeline.py
    retrieval.py
    claims.py
    agents.py
    fusion.py
    datasets.py
    baselines.py
    evaluation.py
    calibration.py
    logger.py
    utils.py
```

## Reproducibility

The repository is intended to preserve the exact configuration, software environment, random seeds, experiment logs, and output files needed for independent verification.

**Important:** this repository should only be described as the exact implementation underlying the manuscript after the authors have validated that correspondence against their experimental code and reported results.

## License

MIT License.


## Phase 4: Experiment Runner and Table Reproduction

Phase 4 adds a reproducible experiment harness and an auditable raw-output
pipeline for Tables 2–6.

### Quick start

Inspect the experiment matrix without generating results:

```bash
python scripts/run_experiments.py \
  --config configs/default.yaml \
  --input examples/demo_inputs.csv \
  --dry-run
```

Validate completed raw results:

```bash
python scripts/validate_raw_outputs.py \
  --input results/raw/predictions_COMPLETED.csv
```

Generate table CSVs:

```bash
python scripts/generate_tables.py \
  --input results/raw/predictions_COMPLETED.csv \
  --output-dir results/tables
```

See `docs/PHASE4_REPRODUCTION_GUIDE.md` for the complete workflow.

### Scientific integrity note

The runner does not fabricate missing results. Dry-run output is explicitly
marked `DRY_RUN` and is rejected by the table-generation script. Actual
manuscript numbers must come from completed experimental runs.


## Phase 5A — Real Model Adapters and FEVER Pilot

Phase 5A adds actual Hugging Face model adapters and a controlled FEVER pilot.

Start with:

```bash
python scripts/prepare_fever.py --split labelled_dev --limit 100
```

Then run a small Qwen2 verification pilot:

```bash
python scripts/run_fever_pilot.py --generator Qwen2 --max-records 10
```

See `docs/PHASE5A.md` before running the experiment.

The pilot is deliberately separated from the final retrieval experiment so that
gold evidence is never accidentally used to claim retrieval performance.


## Phase 5B — True End-to-End Pilot

The true end-to-end pilot is in:

```text
scripts/run_hragmav_fever_e2e.py
```

It requires a separate retrieval corpus and does not use FEVER gold evidence
as retrieval input. See `docs/PHASE5B.md`.
