"""Dependency-light smoke test for the HRAG-MAV control flow.

This does NOT produce paper results. It only checks that the orchestration,
retrieval, claim, agent, and fusion layers can execute.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hragmav.corpus import save_jsonl_corpus
from hragmav.end_to_end import EndToEndHRAGMAV


def main():
    corpus = [
        {"id": "d1", "text": "Paris is the capital and largest city of France."},
        {"id": "d2", "text": "Berlin is the capital of Germany."},
        {"id": "d3", "text": "Canberra is the capital of Australia."},
    ]

    # This smoke test may require the retrieval dependencies from requirements.txt.
    system = EndToEndHRAGMAV(corpus)
    result = system.verify("Paris is the capital of France.")
    print(result)


if __name__ == "__main__":
    main()
