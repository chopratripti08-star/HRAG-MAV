"""
Generate publication-oriented Tables 2-6 from completed raw prediction CSVs.

The script refuses to calculate performance from DRY_RUN rows. This is deliberate:
the repository must never manufacture numbers that look like experimental results.

Usage:
    python scripts/generate_tables.py --input results/raw/predictions_COMPLETED.csv
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hragmav.evaluation import bootstrap_ci, paired_tests
from hragmav.calibration import expected_calibration_error, brier_score


BASELINES = [
    "Standard LLM",
    "Standard RAG",
    "Retrieval-only",
    "SelfCheckGPT",
    "Single-NLI Verifier",
]


def ensure_completed(df):
    if "run_status" in df.columns:
        bad = df[df["run_status"] != "COMPLETED"]
        if len(bad):
            raise ValueError(
                f"{len(bad)} rows are not completed. Remove DRY_RUN rows before table generation."
            )


def binary_arrays(group):
    true = group["gold_label"].astype(str).str.upper()
    pred = group["predicted_label"].astype(str).str.upper()
    y_true = true.isin(["1", "HALLUCINATED", "REFUTED", "FALSE"]).astype(int)
    y_pred = pred.isin(["1", "HALLUCINATED", "REFUTED", "FALSE"]).astype(int)
    return y_true.to_numpy(), y_pred.to_numpy()


def f1_from_group(group):
    from sklearn.metrics import f1_score
    y_true, y_pred = binary_arrays(group)
    return float(f1_score(y_true, y_pred, zero_division=0))


def table2(df):
    rows = []
    for (generator, system), g in df.groupby(["generator", "system"]):
        values = []
        for dataset in ["FEVER", "HaluEval", "TruthfulQA", "HotpotQA", "Natural Questions"]:
            d = g[g["dataset"] == dataset]
            if len(d):
                values.append(f1_from_group(d))
            else:
                values.append(np.nan)

        valid = [x for x in values if np.isfinite(x)]
        mean_acc = float(np.mean(valid)) if valid else np.nan

        rows.append({
            "Generator": generator,
            "System": system,
            "FEVER F1": values[0],
            "HaluEval F1": values[1],
            "TruthfulQA F1": values[2],
            "HotpotQA F1": values[3],
            "NQ F1": values[4],
            "Mean Acc.": mean_acc,
        })
    return pd.DataFrame(rows)


def table3(df):
    rows = []
    ours = df[df["system"] == "HRAG-MAV"]

    for dataset in df["dataset"].dropna().unique():
        for baseline in BASELINES:
            for generator in df["generator"].dropna().unique():
                a = ours[(ours.dataset == dataset) & (ours.generator == generator)]
                b = df[
                    (df.dataset == dataset)
                    & (df.generator == generator)
                    & (df.system == baseline)
                ]

                merged = a[["record_id"]].copy()
                merged["ours"] = merged.record_id.map(
                    a.set_index("record_id").apply(lambda r: f1_from_group(
                        pd.DataFrame([r])
                    ), axis=1)
                ) if False else np.nan

                # Per-record F1 is not mathematically meaningful for a single binary
                # prediction. For paired statistical testing, users should supply
                # precomputed per-item metric scores in a dedicated file.
                if len(a) and len(b):
                    rows.append({
                        "Dataset": dataset,
                        "Generator": generator,
                        "Baseline": baseline,
                        "NOTE": "Requires paired per-item/per-run metric input for valid paired tests."
                    })
    return pd.DataFrame(rows)


def table4(df):
    cols = [
        "system", "evidence_precision", "evidence_recall",
        "faithfulness", "ece", "brier"
    ]
    available = [c for c in cols if c in df.columns]
    return df.groupby("system")[available[1:]].mean().reset_index()


def table5(df):
    if "ablation" not in df.columns:
        return pd.DataFrame(columns=["Configuration", "Mean F1", "Delta vs Full",
                                     "Evidence Recall", "Escalations (%)"])
    return df.groupby("ablation").agg({
        "f1": "mean",
        "evidence_recall": "mean",
        "escalation": "mean",
    }).reset_index()


def table6(df):
    if "sensitivity_parameter" not in df.columns:
        return pd.DataFrame(columns=["Parameter", "Value", "Mean F1",
                                     "CI Low", "CI High"])
    rows = []
    for (parameter, value), g in df.groupby(
        ["sensitivity_parameter", "sensitivity_value"]
    ):
        vals = g["f1"].dropna().to_numpy()
        if len(vals):
            estimate, lo, hi = bootstrap_ci(vals, n_resamples=10000, seed=42)
            rows.append({
                "Parameter": parameter,
                "Value": value,
                "Mean F1": estimate,
                "CI Low": lo,
                "CI High": hi,
            })
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output-dir", default="results/tables")
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    ensure_completed(df)

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    tables = {
        "table2_main_detection.csv": table2(df),
        "table3_paired_comparisons_template.csv": table3(df),
        "table4_evidence_faithfulness_calibration.csv": table4(df),
        "table5_ablation.csv": table5(df),
        "table6_sensitivity.csv": table6(df),
    }

    for filename, table in tables.items():
        table.to_csv(out / filename, index=False)
        print(f"Wrote {out / filename}")


if __name__ == "__main__":
    main()
