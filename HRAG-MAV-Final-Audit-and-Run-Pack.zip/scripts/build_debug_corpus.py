"""Build an engineering-only corpus from FEVER pilot records.

WARNING: this corpus is NOT valid for final retrieval evaluation because it
contains annotated evidence. It is useful only to verify that the retrieval
and reranking code can run end-to-end.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hragmav.corpus import build_debug_corpus_from_records
from hragmav.fever_preprocessing import FeverRecord


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/fever/fever_pilot.jsonl")
    parser.add_argument("--output", default="data/fever/debug_corpus.jsonl")
    args = parser.parse_args()

    records = []
    with open(args.input, encoding="utf-8") as f:
        for line in f:
            records.append(FeverRecord(**json.loads(line)))

    build_debug_corpus_from_records(records, args.output)
    print(f"Saved debug corpus to {args.output}")
    print("WARNING: do not use this corpus for reported FEVER retrieval metrics.")


if __name__ == "__main__":
    main()
