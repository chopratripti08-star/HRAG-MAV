"""
HRAG-MAV experiment runner.

This runner executes a configured experiment matrix and stores one raw row per
system/dataset/generator/example. It intentionally does not fabricate missing
model outputs. A model adapter must be supplied for actual inference.

Typical workflow:
    python scripts/run_experiments.py --config configs/default.yaml --input examples/demo_inputs.csv --dry-run
    python scripts/run_experiments.py --config configs/default.yaml --input data/records.csv

The raw output is written to:
    results/raw/predictions_<timestamp>.csv

The file is the primary audit artifact from which later table-generation scripts
can compute Tables 2-6.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hragmav.utils import load_config, set_seed


@dataclass
class RawPrediction:
    run_id: str
    seed: int
    generator: str
    dataset: str
    record_id: str
    system: str
    question: str
    response: str
    gold_label: str
    predicted_label: str
    score: float
    faithfulness: float
    evidence_precision: float
    evidence_recall: float
    latency_s: float
    tokens: int
    escalation: int
    error_category: str = ""


SYSTEMS = [
    "Standard LLM",
    "Standard RAG",
    "Retrieval-only",
    "SelfCheckGPT",
    "Single-NLI Verifier",
    "HRAG-MAV",
]

GENERATORS = ["Llama-3", "Qwen2"]


def make_run_id(config_path: Path, seed: int) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    digest = hashlib.sha1(config_path.read_bytes()).hexdigest()[:8]
    return f"hragmav_{stamp}_{digest}_seed{seed}"


def load_rows(path: Path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def placeholder_prediction(row, system, generator):
    """
    Safe placeholder used only by --dry-run.

    It deliberately returns an explicit UNRUN status rather than inventing
    performance numbers.
    """
    return {
        "run_status": "DRY_RUN",
        "generator": generator,
        "dataset": row.get("dataset", ""),
        "record_id": row.get("record_id", ""),
        "system": system,
        "question": row.get("question", ""),
        "response": row.get("response", ""),
        "gold_label": row.get("gold_label", ""),
        "predicted_label": "",
        "score": "",
        "faithfulness": "",
        "evidence_precision": "",
        "evidence_recall": "",
        "latency_s": "",
        "tokens": "",
        "escalation": "",
        "error_category": "",
    }


def run_one(row, system, generator, adapter=None):
    if adapter is None:
        raise RuntimeError(
            "No model adapter was supplied. Use --dry-run to inspect the experiment "
            "matrix, or connect the actual experimental models before collecting results."
        )
    start = time.perf_counter()
    result = adapter(row=row, system=system, generator=generator)
    elapsed = time.perf_counter() - start

    required = {
        "predicted_label", "score", "faithfulness",
        "evidence_precision", "evidence_recall",
        "tokens", "escalation"
    }
    missing = required - set(result)
    if missing:
        raise ValueError(f"Adapter result is missing fields: {sorted(missing)}")

    result.setdefault("run_status", "COMPLETED")
    result["latency_s"] = float(result.get("latency_s", elapsed))
    result.update({
        "generator": generator,
        "dataset": row.get("dataset", ""),
        "record_id": row.get("record_id", ""),
        "system": system,
        "question": row.get("question", ""),
        "response": row.get("response", ""),
        "gold_label": row.get("gold_label", ""),
    })
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--datasets", nargs="*", default=None)
    parser.add_argument("--systems", nargs="*", default=SYSTEMS)
    parser.add_argument("--generators", nargs="*", default=GENERATORS)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    config_path = Path(args.config)
    config = load_config(config_path)
    seed = args.seed if args.seed is not None else int(config.get("seed", 42))
    set_seed(seed)

    rows = load_rows(Path(args.input))
    if args.datasets:
        rows = [r for r in rows if r.get("dataset") in args.datasets]

    run_id = make_run_id(config_path, seed)

    out = Path(args.output) if args.output else Path(
        "results/raw"
    ) / f"predictions_{run_id}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)

    results = []
    for generator in args.generators:
        for system in args.systems:
            for row in rows:
                if args.dry_run:
                    result = placeholder_prediction(row, system, generator)
                else:
                    result = run_one(row, system, generator)
                result["run_id"] = run_id
                result["seed"] = seed
                results.append(result)

    fieldnames = [
        "run_id", "seed", "run_status", "generator", "dataset", "record_id",
        "system", "question", "response", "gold_label", "predicted_label",
        "score", "faithfulness", "evidence_precision", "evidence_recall",
        "latency_s", "tokens", "escalation", "error_category"
    ]

    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

    print(f"Wrote {len(results)} raw rows to {out}")
    print(f"Run ID: {run_id}")


if __name__ == "__main__":
    main()
