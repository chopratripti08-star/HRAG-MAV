"""Small command-line example for running statistical utilities.

This script does not fabricate benchmark results. It demonstrates how recorded
per-run metric values can be compared and corrected for multiple testing.
"""

import argparse
import json
from pathlib import Path

import numpy as np

from hragmav.evaluation import paired_tests, holm_bonferroni


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ours", required=True, help="CSV/NPY file with paired metric values")
    parser.add_argument("--baseline", required=True)
    args = parser.parse_args()

    ours = np.loadtxt(args.ours, delimiter=",")
    baseline = np.loadtxt(args.baseline, delimiter=",")

    result = paired_tests(ours, baseline)
    adjusted = holm_bonferroni([result["wilcoxon_p"], result["paired_t_p"]])

    result["wilcoxon_p_holm"] = float(adjusted[0])
    result["paired_t_p_holm"] = float(adjusted[1])

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
