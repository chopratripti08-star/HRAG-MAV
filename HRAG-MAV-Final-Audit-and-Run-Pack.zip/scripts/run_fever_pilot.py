"""
Run the first genuine HRAG-MAV FEVER pilot.

This is intentionally small. The purpose is to validate the complete chain
before committing to the full five-dataset experiment.

The pilot:
1. loads normalized FEVER records;
2. builds a tiny evidence corpus from gold evidence for pipeline debugging;
3. runs the selected generator;
4. asks the model to verify each claim;
5. writes raw predictions.

IMPORTANT:
For the publication experiment, retrieval must be performed against the
specified retrieval corpus rather than gold evidence. Gold evidence here is
used only to debug the model-verification path and must not be used as the
retrieval input for the final reported experiment.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hragmav.model_adapters import (
    HuggingFaceGenerator,
    make_fact_check_prompt,
    parse_verdict,
)
from hragmav.fever_preprocessing import FeverRecord


def load_jsonl(path):
    records = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            records.append(FeverRecord(**json.loads(line)))
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/fever/fever_pilot.jsonl")
    parser.add_argument("--output", default="results/pilot/fever_pilot_predictions.csv")
    parser.add_argument("--generator", choices=["Llama-3", "Qwen2"], default="Qwen2")
    parser.add_argument("--max-records", type=int, default=10)
    args = parser.parse_args()

    records = load_jsonl(args.input)[:args.max_records]
    if not records:
        raise RuntimeError("No FEVER records found. Run prepare_fever.py first.")

    generator = HuggingFaceGenerator(args.generator)

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)

    fields = [
        "generator", "dataset", "record_id", "gold_label",
        "prediction", "rationale", "score",
        "prompt_tokens", "completion_tokens", "latency_s"
    ]

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()

        for record in records:
            prompt = make_fact_check_prompt(record.claim, record.evidence)
            result = generator.generate(prompt)
            parsed = parse_verdict(result.text)

            score = {
                "SUPPORTED": 1.0,
                "REFUTED": 0.0,
                "NOT_ENOUGH_INFO": 0.5,
            }[parsed["verdict"]]

            writer.writerow({
                "generator": args.generator,
                "dataset": "FEVER",
                "record_id": record.record_id,
                "gold_label": record.label,
                "prediction": parsed["verdict"],
                "rationale": parsed["rationale"],
                "score": score,
                "prompt_tokens": result.prompt_tokens,
                "completion_tokens": result.completion_tokens,
                "latency_s": result.latency_s,
            })

            print(record.record_id, parsed["verdict"], record.label)

    print(f"Saved pilot predictions to {args.output}")


if __name__ == "__main__":
    main()
