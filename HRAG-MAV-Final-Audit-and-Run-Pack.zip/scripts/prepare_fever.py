"""Download/normalize a reproducible FEVER pilot subset."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hragmav.fever_preprocessing import load_huggingface_fever, save_jsonl


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--split", default="labelled_dev")
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--output", default="data/fever/fever_pilot.jsonl")
    args = parser.parse_args()

    records = load_huggingface_fever(args.split, args.limit)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    save_jsonl(records, args.output)

    print(f"Saved {len(records)} FEVER records to {args.output}")
    labels = {}
    for r in records:
        labels[r.label] = labels.get(r.label, 0) + 1
    print("Label distribution:", labels)


if __name__ == "__main__":
    main()
