"""
Run a true end-to-end HRAG-MAV FEVER pilot against an externally supplied corpus.

The model generates an answer to the FEVER claim, then HRAG-MAV verifies the
generated answer using retrieved evidence. Gold evidence is used only for
post-hoc retrieval diagnostics if requested; it is never passed to retrieval.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hragmav.model_adapters import HuggingFaceGenerator
from hragmav.corpus import load_jsonl_corpus
from hragmav.end_to_end import EndToEndHRAGMAV


def load_records(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/fever/fever_pilot.jsonl")
    parser.add_argument("--corpus", required=True)
    parser.add_argument("--output", default="results/raw/fever_hragmav_e2e.csv")
    parser.add_argument("--generator", choices=["Llama-3", "Qwen2"], default="Qwen2")
    parser.add_argument("--max-records", type=int, default=10)
    args = parser.parse_args()

    records = load_records(args.input)[:args.max_records]
    corpus = load_jsonl_corpus(args.corpus)

    generator = HuggingFaceGenerator(args.generator, max_new_tokens=256)
    system = EndToEndHRAGMAV(corpus)

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)

    fields = [
        "generator", "dataset", "record_id", "gold_label",
        "generated_response", "response_hallucination_score",
        "claim_count", "predicted_labels", "retrieved_doc_ids",
        "retrieved_scores"
    ]

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()

        for record in records:
            # Generation task: turn the FEVER claim into a factual question.
            prompt = (
                "Answer the following factual statement as a short factual response. "
                "Do not discuss this instruction.\n\n"
                f"Statement: {record['claim']}\n\nAnswer:"
            )
            generated = generator.generate(prompt)
            verified = system.verify(generated.text)

            claims = verified["claims"]
            labels = [c["verdict"] for c in claims]
            doc_ids = [
                e["doc_id"]
                for c in claims
                for e in c["evidence"]
            ]
            scores = [
                e["score"]
                for c in claims
                for e in c["evidence"]
            ]

            writer.writerow({
                "generator": args.generator,
                "dataset": "FEVER",
                "record_id": record["record_id"],
                "gold_label": record["label"],
                "generated_response": generated.text,
                "response_hallucination_score": verified["response_hallucination_score"],
                "claim_count": len(claims),
                "predicted_labels": "|".join(labels),
                "retrieved_doc_ids": "|".join(doc_ids),
                "retrieved_scores": "|".join(map(str, scores)),
            })

            print(record["record_id"], "->", labels)

    print(f"Saved end-to-end pilot to {args.output}")


if __name__ == "__main__":
    main()
