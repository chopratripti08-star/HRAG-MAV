"""Validate the raw-result schema before publication."""

from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd


REQUIRED = [
    "run_id", "seed", "run_status", "generator", "dataset", "record_id",
    "system", "gold_label", "predicted_label", "score",
    "latency_s", "tokens", "escalation"
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise SystemExit(f"Missing required columns: {missing}")

    status = df["run_status"].value_counts(dropna=False).to_dict()
    print("Run status:", status)

    if set(df["run_status"].dropna().unique()) - {"COMPLETED"}:
        print("WARNING: output contains non-completed rows.")
        print("Do not use these rows to generate manuscript tables.")

    print("Rows:", len(df))
    print("Generators:", sorted(df["generator"].dropna().unique()))
    print("Systems:", sorted(df["system"].dropna().unique()))
    print("Datasets:", sorted(df["dataset"].dropna().unique()))


if __name__ == "__main__":
    main()
