# Phase 4 — Reproducing Tables 2–6

This guide is intentionally conservative: the scripts calculate results from
actual raw experiment outputs and do not insert the manuscript's published
numbers as placeholders.

## 1. Understand the experiment matrix

The manuscript evaluates:

**Generators**
- Llama-3-8B-Instruct
- Qwen2-7B-Instruct

**Datasets**
- FEVER
- HaluEval
- TruthfulQA
- HotpotQA
- Natural Questions

**Systems**
- Standard LLM
- Standard RAG
- Retrieval-only
- SelfCheckGPT
- Single-NLI Verifier
- HRAG-MAV

The paper states that all systems expose a common score interface and that the
decision threshold is optimized on the calibration split rather than the test
split. It also reports 95% percentile bootstrap confidence intervals with
10,000 resamples.

## 2. Prepare the actual data

The dataset adapters in `hragmav/datasets.py` are starting points. Before the
paper is submitted, verify:

- exact dataset versions
- exact split
- exact sample filtering
- exact record IDs
- exact gold-label mapping
- exact evidence annotation mapping

Do not assume that a package's current default split is identical to the split
used in the study.

## 3. Connect the real model adapters

`run_experiments.py` deliberately requires an adapter for real inference.

The adapter must call the actual experimental implementation for:

- Standard LLM
- Standard RAG
- Retrieval-only
- SelfCheckGPT
- Single-NLI Verifier
- HRAG-MAV

and return the fields specified in `results/raw/README.md`.

This is the point at which the actual Llama-3/Qwen2 inference code and the
actual HRAG-MAV implementation should be connected.

## 4. Inspect the experiment matrix

```bash
python scripts/run_experiments.py \
  --config configs/default.yaml \
  --input examples/demo_inputs.csv \
  --dry-run
```

This creates a schema-correct dry-run CSV. It is **not experimental evidence**.

## 5. Run real experiments

After the actual adapter is connected:

```bash
python scripts/run_experiments.py \
  --config configs/default.yaml \
  --input data/records.csv
```

For a specific generator/dataset:

```bash
python scripts/run_experiments.py \
  --config configs/default.yaml \
  --input data/records.csv \
  --generators Llama-3 \
  --datasets FEVER
```

For repeated seeds:

```bash
python scripts/run_experiments.py \
  --config configs/default.yaml \
  --input data/records.csv \
  --seed 42
```

Repeat with the pre-registered seeds and retain every raw CSV.

**Do not claim multi-seed results unless the experiments were actually run
multiple times.**

## 6. Validate the raw output

```bash
python scripts/validate_raw_outputs.py \
  --input results/raw/predictions_COMPLETED.csv
```

The validator checks the raw schema and flags incomplete/dry-run rows.

## 7. Generate Tables 2–6

```bash
python scripts/generate_tables.py \
  --input results/raw/predictions_COMPLETED.csv \
  --output-dir results/tables
```

### Table 2

Main hallucination-detection performance:

- generator
- system
- FEVER F1
- HaluEval F1
- TruthfulQA F1
- HotpotQA F1
- Natural Questions F1
- mean accuracy

The manuscript reports these values with 95% confidence intervals.

### Table 3

Paired HRAG-MAV vs baseline comparison:

- ΔF1
- 95% CI
- Wilcoxon p-value
- Holm-adjusted p-value
- paired Cohen's d
- Cliff's δ
- significance

**Important:** valid paired statistical testing requires paired per-item or
per-run metric observations. A single aggregate F1 value per system is not
enough to reconstruct a valid paired test. Supply the actual paired observations.

### Table 4

Evidence retrieval and calibration:

- FEVER evidence precision
- FEVER evidence recall
- HotpotQA evidence precision
- HotpotQA evidence recall
- faithfulness
- ECE
- Brier score

### Table 5

Component ablation:

- full HRAG-MAV
- fixed alpha
- no cross-encoder
- dense-only
- BM25-only
- no grounding agent
- no adjudicator
- mean-pool confidence fusion

### Table 6

Sensitivity analysis:

- retrieval depth k
- evidence passages per claim m
- escalation threshold
- NLI decision threshold
- SelfCheckGPT sampling count

## 8. Audit trail

For every reported table, retain:

```text
raw CSV
        ↓
processing script
        ↓
processed CSV
        ↓
table CSV
        ↓
manuscript table
```

The GitHub repository should contain the scripts and, where licensing/privacy
allows, representative raw outputs or a clearly documented archive containing
the full outputs.

## 9. What must be checked before submission

- [ ] Every reported Table 2 number can be traced to raw predictions.
- [ ] Every Table 3 statistical comparison can be traced to paired observations.
- [ ] Table 4 uses actual evidence annotations.
- [ ] Table 5 uses actual ablation runs.
- [ ] Table 6 uses actual sensitivity runs.
- [ ] Seeds are documented.
- [ ] Dataset versions/splits are documented.
- [ ] Hardware and software environment are documented.
- [ ] No dry-run or manually entered values are used.
- [ ] The GitHub repository is public/archived as appropriate.
