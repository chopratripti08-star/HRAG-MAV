# Reproducibility Checklist

Before public release, verify each item.

## Code

- [ ] `pipeline.py` corresponds to the implemented end-to-end workflow.
- [ ] `retrieval.py` corresponds to the retrieval implementation.
- [ ] `claims.py` corresponds to claim extraction.
- [ ] `agents.py` corresponds to verification agents.
- [ ] `fusion.py` corresponds to confidence fusion.
- [ ] Dataset loaders are included.
- [ ] Baselines are included.
- [ ] Evaluation scripts reproduce reported statistics.

## Environment

- [ ] Python version documented.
- [ ] Package versions frozen.
- [ ] GPU/CPU specifications documented.
- [ ] CUDA version documented if applicable.

## Experiments

- [ ] Random seeds documented.
- [ ] Dataset versions/splits documented.
- [ ] Configuration files preserved.
- [ ] Raw run logs preserved.
- [ ] CSV outputs for reported tables preserved.
- [ ] Ablation configurations preserved.
- [ ] Sensitivity-analysis configurations preserved.

## Publication

- [ ] GitHub repository is public before submission if journal policy permits.
- [ ] Repository URL is inserted into manuscript.
- [ ] Long-term archive/DOI is created where appropriate.
- [ ] README explains reproduction steps.
