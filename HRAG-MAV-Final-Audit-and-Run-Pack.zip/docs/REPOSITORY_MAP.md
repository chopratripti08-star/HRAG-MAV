# Repository Map

| Manuscript component | Repository component |
|---|---|
| Algorithm 1: End-to-end HRAG-MAV | `hragmav/pipeline.py` |
| Algorithm 2: Adaptive hybrid retrieval | `hragmav/retrieval.py` |
| Algorithm 3: Claim extraction | `hragmav/claims.py` |
| Algorithm 4: Multi-agent verification | `hragmav/agents.py`, `hragmav/fusion.py` |
| Algorithm 5: Explainable output | `hragmav/pipeline.py` |
| Dataset loaders | `hragmav/datasets.py` |
| Baselines | `hragmav/baselines.py` |
| Statistical evaluation | `hragmav/evaluation.py` |
| Calibration | `hragmav/calibration.py` |
| Logging | `hragmav/logger.py` |
| Configuration | `configs/default.yaml` |
