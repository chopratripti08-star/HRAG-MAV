# Final HRAG-MAV Repository Map

## Phase 1 — Infrastructure
- README
- LICENSE
- CITATION.cff
- requirements.txt
- environment.yml
- setup.py
- pyproject.toml
- configs/default.yaml
- reproducibility documentation

## Phase 2 — Core framework
- pipeline.py
- retrieval.py
- claims.py
- agents.py
- fusion.py

## Phase 3 — Experimental layer
- datasets.py
- baselines.py
- evaluation.py
- calibration.py
- logger.py
- utils.py

## Tests
- tests/test_imports.py
- tests/test_evaluation.py

## Scripts
- scripts/run_evaluation.py

## Before GitHub submission
1. Validate the exact dataset versions/splits.
2. Connect the actual model checkpoints used in the study.
3. Record hardware/CUDA information.
4. Run the full experimental suite.
5. Save raw outputs and logs.
6. Verify that manuscript tables are reproducible from repository outputs.
7. Replace placeholder GitHub information.
8. Create a tagged release/long-term archive after validation.
