# Phase 5B — True End-to-End FEVER HRAG-MAV Pilot

## What Phase 5B accomplishes

This phase connects the components into the intended sequence:

```text
FEVER claim
   ↓
LLM response generation
   ↓
atomic claim extraction
   ↓
BM25 + dense retrieval
   ↓
RRF fusion
   ↓
cross-encoder reranking
   ↓
entailment agent
   ↓
grounding agent
   ↓
adjudicator when needed
   ↓
confidence fusion
   ↓
raw CSV audit trail
```

## Critical rule

The final evaluation **must not retrieve from FEVER's gold evidence**.

The repository therefore requires a separate retrieval corpus:

```text
{"id": "...", "text": "..."}
```

The corpus must correspond to the retrieval source/version defined in the
manuscript.

### Debug corpus

`scripts/build_debug_corpus.py` can create a tiny corpus from FEVER evidence,
but this is **engineering-only** and explicitly must not be used for reported
retrieval results.

## Run sequence

### A. Prepare FEVER pilot

```bash
python scripts/prepare_fever.py \
  --split labelled_dev \
  --limit 10
```

### B. Supply a retrieval corpus

Example:

```text
data/fever/retrieval_corpus.jsonl
```

Do not place gold test evidence into this file for the final evaluation.

### C. Run the true end-to-end pilot

```bash
python scripts/run_hragmav_fever_e2e.py \
  --input data/fever/fever_pilot.jsonl \
  --corpus data/fever/retrieval_corpus.jsonl \
  --generator Qwen2 \
  --max-records 10
```

Then repeat with Llama-3 after model access is configured:

```bash
python scripts/run_hragmav_fever_e2e.py \
  --input data/fever/fever_pilot.jsonl \
  --corpus data/fever/retrieval_corpus.jsonl \
  --generator Llama-3 \
  --max-records 10
```

## Do not scale yet

Do not run thousands of examples until these ten-example pilots have been
manually inspected.

Check:

- generated responses are sensible;
- claims are decomposed sensibly;
- retrieved passages are genuinely relevant;
- reranking is not broken;
- NLI labels make sense;
- grounding scores are reasonable;
- adjudication is triggered only when intended;
- confidence fusion is numerically stable;
- every raw record contains enough information to reproduce the decision.

## After the pilot

If the ten-example pilot is valid, expand to:

1. 100 FEVER records;
2. the complete chosen calibration split;
3. the complete chosen test split;
4. multiple seeds;
5. Qwen2;
6. Llama-3;
7. the remaining datasets.

Only then should Tables 2–6 be regenerated.

## Why this order matters

The paper currently reports very strong and consistent results. The objective is
not to force the new implementation to reproduce those numbers. The objective is
to discover what the actual implementation produces and then reconcile the
manuscript with the verified experiment.

If the verified results differ, the manuscript tables must be corrected.
