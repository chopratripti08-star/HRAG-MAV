# HRAG-MAV Submission Rescue Audit

## Why this file exists

The manuscript already contains detailed numerical results. The repository must
not be used to reverse-engineer those numbers. The correct sequence is:

**independent run → raw outputs → statistics → manuscript tables**

## Findings that need attention before submission

### 1. Seed reproducibility is underspecified

The manuscript says that the seed is set for reproducibility, but the results
section describes confidence intervals as percentile bootstrap over 10,000
resamples. A bootstrap CI over examples is not the same thing as demonstrating
stability across independent random seeds.

**Action:** record every seed actually run. If only one seed was used, say so.
Do not write “N=5 seeds” unless five seeds were actually executed.

### 2. Table 2 needs raw per-example predictions

The paper reports very clean confidence intervals and a consistent ranking across
five datasets and two generators. The repository therefore needs the raw
prediction rows from which each cell is calculated.

### 3. Table 3 requires genuine paired observations

A single aggregate F1 value cannot reproduce a valid paired Wilcoxon test or
paired Cohen's d. The repository must retain the paired unit used for the
analysis (e.g., per-example score or per-run score, exactly as defined in the
analysis protocol).

### 4. Table 4 requires evidence annotations

The manuscript states that evidence precision/recall are calculated against
gold evidence for FEVER and HotpotQA. The retrieval output must therefore
preserve retrieved document IDs and the mapping to gold evidence.

### 5. Table 5 requires actual ablation runs

The manuscript reports numerical degradation for fixed alpha, no reranking,
dense-only, BM25-only, no grounding agent, no adjudicator and mean-pool fusion.
Those values should be regenerated from actual ablation executions.

### 6. Table 6 requires actual timing logs

Latency, tokens/query and response time must come from execution logs on the
documented hardware/software environment. They should not be copied from the
manuscript into CSV files.

### 7. Error analysis needs actual examples

The current manuscript gives an error taxonomy and percentages but qualitative
examples need to come from actual failed predictions. Preserve:

- record ID
- claim
- generated response
- retrieved evidence
- agent decisions
- final verdict
- gold label
- error category
- short explanation

### 8. Do not force the new implementation to match the existing tables

If the independent implementation gives different values, the manuscript
numbers should be corrected and the reason documented.

## Manuscript facts to preserve during reconciliation

The manuscript states:

- two generators: Llama-3-8B-Instruct and Qwen2-7B-Instruct;
- dense retrieval: all-mpnet-base-v2 with FAISS inner-product indexing;
- sparse retrieval: rank_bm25;
- reranking: MiniLM cross-encoder;
- entailment: DeBERTa-v3 MNLI;
- entity extraction: spaCy;
- orchestration: LangChain;
- thresholds optimized on the calibration split;
- 95% percentile bootstrap CIs with 10,000 resamples.

These should be treated as the target experimental specification, not as evidence
that the experiment has already been reproduced.

## Recommended decision gate

Do not submit the paper until at least:

1. one real FEVER Qwen2 pilot is completed;
2. one real FEVER Llama-3 pilot is completed;
3. retrieved evidence is independently sourced;
4. raw CSVs are inspected;
5. the full FEVER run is reproducible;
6. then the five-dataset matrix is executed;
7. Tables 2–6 are regenerated from those outputs.
