# Phase 5B Hardware and Runtime Guidance

## Model size

Qwen2-7B-Instruct is an approximately 8B-parameter BF16 model and its official
Hugging Face repository lists a model footprint of about 15.2 GB across the
safetensor shards.

Llama-3-8B-Instruct is also an 8B-parameter model.

A practical full-precision/BF16 local run therefore needs a suitable GPU and
additional memory for inference, tokenizer/model overhead, retrieval, and
runtime processes.

## Minimum practical approach

Use a GPU machine with enough VRAM for the chosen loading strategy. If VRAM is
insufficient, use an explicitly documented quantization/offloading strategy
and record it in the experiment manifest.

Do not silently switch models or quantization methods while claiming the
manuscript's original configuration.

## Record

For every final run, save:

- GPU model
- VRAM
- CUDA version
- PyTorch version
- Transformers version
- model revision/hash
- dataset revision
- random seed
- retrieval corpus version/hash
- configuration file
