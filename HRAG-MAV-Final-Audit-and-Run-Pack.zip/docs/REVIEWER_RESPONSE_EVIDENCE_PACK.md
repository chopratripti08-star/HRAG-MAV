# Reviewer Response Evidence Pack

## Comment 1 — Data Availability / Reproducibility

**Response after actual runs:**

> We have made the research code publicly available and added machine-readable
> configuration files, environment specifications, experiment scripts, raw
> prediction outputs, and table-generation scripts. Each reported result can be
> traced from the manuscript table to processed outputs and then to raw
> per-example/per-run observations.

Only use this response once the repository and raw outputs actually exist.

## Comment 2 — Too-clean results / seeds

Choose exactly one truthful statement:

### If one seed was run

> Results were obtained using a single fixed random seed. The manuscript has
> been revised to state this explicitly as a limitation. Bootstrap confidence
> intervals quantify uncertainty over the evaluation observations and should not
> be interpreted as evidence of cross-seed stability.

### If multiple seeds were actually run

> Results are aggregated across N independent seeds. We now report the
> per-seed mean and standard deviation in the supplementary material, in
> addition to the percentile bootstrap confidence intervals over evaluation
> observations.

Do not use the second statement unless the runs actually happened.

## Comment 3 — Author / affiliation

Remove every bracketed author placeholder. Verify:

- author names
- affiliations
- corresponding author
- ORCID if required
- acknowledgments
- funding statement

Do not add an institutional co-author merely to create a stronger appearance.

## Comment 4 — AI-use disclosure

Replace the manuscript placeholder with a factual statement describing the
actual use of AI tools. Distinguish:

- writing assistance
- grammar/editing
- code generation
- code debugging
- analysis
- figures

The disclosure must describe what actually happened.

## Comment 5 — Error analysis

Add 2–3 real examples from the completed raw run. Do not invent examples.
Each example should show claim → retrieved evidence → agent verdicts → final
verdict → gold label → failure category.

## Comment 6 — Related work

Add the requested comparison table only after checking the cited papers and
accurately stating what RARR, FacTool and the multi-agent/debate approaches do.
Do not claim a feature is absent unless the cited work supports that statement.
