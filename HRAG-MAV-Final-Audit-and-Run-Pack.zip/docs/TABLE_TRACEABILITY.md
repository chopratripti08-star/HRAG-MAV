# Table Traceability Matrix

| Manuscript table | Raw source | Processing | Final artifact |
|---|---|---|---|
| Table 2 | `results/raw/*.csv` | `scripts/generate_tables.py` | `results/tables/table2_main_detection.csv` |
| Table 3 | paired raw observations | `hragmav/evaluation.py` | `results/tables/table3_paired_comparisons.csv` |
| Table 4 | evidence/calibration fields | `hragmav/calibration.py` + table generator | `results/tables/table4_evidence_faithfulness_calibration.csv` |
| Table 5 | ablation runs | table generator | `results/tables/table5_ablation.csv` |
| Table 6 | sensitivity runs | bootstrap/table generator | `results/tables/table6_sensitivity.csv` |

## Critical reviewer requirement

Do not use a final aggregate table as the only evidence. Preserve the raw
per-example/per-run observations from which the aggregate table was computed.
