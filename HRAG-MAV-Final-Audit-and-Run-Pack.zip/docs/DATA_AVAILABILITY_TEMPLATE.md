# Data Availability Statement

The benchmark datasets used in HRAG-MAV are publicly available from their
respective original sources. This repository should contain dataset-loading
scripts and configuration files rather than redistributing datasets whose
licenses prohibit redistribution.

## Code

Insert the final public repository URL here after the repository has been
validated and made public.

## Experimental outputs

For each reported experiment, the final repository should contain the raw
CSV/log outputs necessary to trace the reported tables back to individual
experimental runs.

## Long-term archive

After publication/submission, consider depositing a tagged release in a
long-term archive such as Zenodo and record the DOI here.
