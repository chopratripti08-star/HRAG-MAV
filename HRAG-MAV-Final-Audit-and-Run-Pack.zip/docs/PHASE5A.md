# Phase 5A — Real Model Adapters + FEVER Pilot

## Purpose

Phase 5A moves the repository from experiment infrastructure toward a genuine
model-backed pilot.

It adds:

- real Hugging Face generation adapters for Llama-3 and Qwen2;
- FEVER v1.0 preprocessing;
- a small FEVER pilot;
- raw prediction output.

## Important experimental distinction

The first pilot intentionally uses FEVER's annotated evidence to validate the
**model verification path**. This is a debugging/control experiment, not the
final retrieval experiment.

For the paper's final results, HRAG-MAV must retrieve evidence from the defined
retrieval corpus and then verify that retrieved evidence. Using gold evidence
directly would leak the answer and invalidate the retrieval evaluation.

## Step 1 — Install dependencies

```bash
pip install -r requirements.txt
```

For GPU inference, install the appropriate PyTorch build for the target CUDA
environment.

## Step 2 — Qwen2 pilot

Qwen2-7B-Instruct is available from Hugging Face and its model card documents
Transformers-based loading. The model is large, so use an appropriate GPU or
an explicitly tested quantized/offloaded setup.

```bash
python scripts/prepare_fever.py \
  --split labelled_dev \
  --limit 100 \
  --output data/fever/fever_pilot.jsonl
```

Then:

```bash
python scripts/run_fever_pilot.py \
  --input data/fever/fever_pilot.jsonl \
  --generator Qwen2 \
  --max-records 10
```

## Step 3 — Llama-3 pilot

Llama-3 requires access authorization for the gated model repository.

After Hugging Face access is configured:

```bash
python scripts/run_fever_pilot.py \
  --input data/fever/fever_pilot.jsonl \
  --generator Llama-3 \
  --max-records 10
```

## Step 4 — What to inspect

Do not compare the pilot F1 with the manuscript table yet.

First check:

- Are claims loaded correctly?
- Are labels mapped correctly?
- Does the model produce one of the three expected verdicts?
- Are prompt/completion token counts recorded?
- Are latency measurements recorded?
- Are record IDs preserved?
- Are raw outputs reproducible with the same seed/configuration?

## Step 5 — After pilot validation

Only after the pilot passes should we connect:

1. the actual Wikipedia retrieval corpus;
2. BM25;
3. dense retrieval;
4. FAISS;
5. cross-encoder reranking;
6. claim decomposition;
7. entailment agent;
8. grounding agent;
9. adjudicator;
10. confidence calibration.

Then the FEVER experiment can become the first **true end-to-end HRAG-MAV experiment**.

## Hardware note

An 8B model is not a lightweight CPU experiment. The repository does not assume
that the current ChatGPT runtime can download and execute the model weights.
The actual pilot should therefore be run on a suitable GPU machine or hosted
inference environment, with the hardware and software environment recorded
for reproducibility.
