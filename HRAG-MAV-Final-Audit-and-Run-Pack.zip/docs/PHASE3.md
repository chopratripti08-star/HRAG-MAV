# Phase 3 — Datasets, Baselines, Evaluation, Calibration and Logging

Phase 3 connects the HRAG-MAV core reference implementation to the experimental
and reproducibility layer.

## Components

### `datasets.py`
Provides adapters for:

- FEVER
- HaluEval
- TruthfulQA
- HotpotQA
- Natural Questions

The exact dataset revision, split, and field mapping must be validated against
the version used in the study.

### `baselines.py`
Provides interfaces for:

- Standard LLM
- Standard RAG
- Retrieval-only
- SelfCheckGPT
- Single-NLI Verifier

The actual model calls must be connected to the experimental implementations.

### `evaluation.py`
Provides:

- precision
- recall
- F1
- accuracy
- bootstrap confidence intervals
- paired t-test
- Wilcoxon signed-rank test
- paired Cohen's d
- Cliff's delta
- Holm-Bonferroni correction

### `calibration.py`
Provides:

- temperature scaling
- Expected Calibration Error
- Brier score

Temperature scaling should be fitted only on the calibration/held-out split,
never on the final test split.

### `logger.py`
Stores JSONL and CSV run records.

## Important scientific-use note

These modules are designed to support a reproducible research workflow. They do
not create or reconstruct missing experimental results. The authors should
connect them to the actual dataset versions, model checkpoints, seeds, hardware,
and experiment scripts used to obtain the manuscript's reported results.

## Reviewer-response use

Once validated, the repository can support the manuscript's Data Availability /
Reproducibility response by preserving:

- configuration files
- exact environment
- per-run logs
- raw prediction CSVs
- statistical-analysis inputs
- generated tables
- dataset split identifiers
